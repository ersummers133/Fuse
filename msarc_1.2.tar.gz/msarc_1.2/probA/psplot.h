/* Last changed Time-stamp: <2001-03-26 09:36:44 ulim> */
/* psplot.h */

#ifndef _PSPLOT_H_
#define _PSPLOT_H_
extern int PS_plot(sequ os, real **P, char *wastlfile);
#endif
/* End of file */
